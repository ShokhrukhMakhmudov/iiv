import React from "react";
import UploadCertificates from "../../../components/UploadCertificates";

export default function page() {
  return <UploadCertificates />;
}
