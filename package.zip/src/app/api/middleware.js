export const config = {
  api: {
    bodyParser: {
      sizeLimit: "10mb",
    },
  },
};

export const config200 = {
  api: {
    bodyParser: {
      sizeLimit: "200mb",
    },
  },
};
